﻿namespace HH
{
    partial class AddTT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.SCODE = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SNAME = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label37 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listView2 = new System.Windows.Forms.ListView();
            this.TID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TeacherName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SHORT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label38 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Monday = new System.Windows.Forms.TabPage();
            this.monday62 = new System.Windows.Forms.ComboBox();
            this.monday61 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.monday52 = new System.Windows.Forms.ComboBox();
            this.monday51 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.monday42 = new System.Windows.Forms.ComboBox();
            this.monday41 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.monday32 = new System.Windows.Forms.ComboBox();
            this.monday31 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.monday22 = new System.Windows.Forms.ComboBox();
            this.monday21 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.monday12 = new System.Windows.Forms.ComboBox();
            this.monday11 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Tuesday = new System.Windows.Forms.TabPage();
            this.tuesday62 = new System.Windows.Forms.ComboBox();
            this.tuesday61 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tuesday52 = new System.Windows.Forms.ComboBox();
            this.tuesday51 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tuesday42 = new System.Windows.Forms.ComboBox();
            this.tuesday41 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tuesday32 = new System.Windows.Forms.ComboBox();
            this.tuesday31 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tuesday22 = new System.Windows.Forms.ComboBox();
            this.tuesday21 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tuesday12 = new System.Windows.Forms.ComboBox();
            this.tuesday11 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Wednesday = new System.Windows.Forms.TabPage();
            this.wednesday62 = new System.Windows.Forms.ComboBox();
            this.wednesday61 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.wednesday52 = new System.Windows.Forms.ComboBox();
            this.wednesday51 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.wednesday42 = new System.Windows.Forms.ComboBox();
            this.wednesday41 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.wednesday32 = new System.Windows.Forms.ComboBox();
            this.wednesday31 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.wednesday22 = new System.Windows.Forms.ComboBox();
            this.wednesday21 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.wednesday12 = new System.Windows.Forms.ComboBox();
            this.wednesday11 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.Thursday = new System.Windows.Forms.TabPage();
            this.thursday62 = new System.Windows.Forms.ComboBox();
            this.thursday61 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.thursday52 = new System.Windows.Forms.ComboBox();
            this.thursday51 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.thursday42 = new System.Windows.Forms.ComboBox();
            this.thursday41 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.thursday32 = new System.Windows.Forms.ComboBox();
            this.thursday31 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.thursday22 = new System.Windows.Forms.ComboBox();
            this.thursday21 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.thursday12 = new System.Windows.Forms.ComboBox();
            this.thursday11 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Friday = new System.Windows.Forms.TabPage();
            this.friday62 = new System.Windows.Forms.ComboBox();
            this.friday61 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.friday52 = new System.Windows.Forms.ComboBox();
            this.friday51 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.friday42 = new System.Windows.Forms.ComboBox();
            this.friday41 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.friday32 = new System.Windows.Forms.ComboBox();
            this.friday31 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.friday22 = new System.Windows.Forms.ComboBox();
            this.friday21 = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.friday12 = new System.Windows.Forms.ComboBox();
            this.friday11 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.Saturday = new System.Windows.Forms.TabPage();
            this.saturday62 = new System.Windows.Forms.ComboBox();
            this.saturday61 = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.saturday52 = new System.Windows.Forms.ComboBox();
            this.saturday51 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.saturday42 = new System.Windows.Forms.ComboBox();
            this.saturday41 = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.saturday32 = new System.Windows.Forms.ComboBox();
            this.saturday31 = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.saturday22 = new System.Windows.Forms.ComboBox();
            this.saturday21 = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.saturday12 = new System.Windows.Forms.ComboBox();
            this.saturday11 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Monday.SuspendLayout();
            this.Tuesday.SuspendLayout();
            this.Wednesday.SuspendLayout();
            this.Thursday.SuspendLayout();
            this.Friday.SuspendLayout();
            this.Saturday.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.listView1);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 240);
            this.panel2.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.SCODE,
            this.SNAME});
            this.listView1.Location = new System.Drawing.Point(21, 41);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(357, 188);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // SCODE
            // 
            this.SCODE.Text = "Subject Code";
            this.SCODE.Width = 80;
            // 
            // SNAME
            // 
            this.SNAME.Text = "Subject Name";
            this.SNAME.Width = 272;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(18, 13);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(171, 16);
            this.label37.TabIndex = 0;
            this.label37.Text = "Subject Of Selected Branch";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.listView2);
            this.panel3.Controls.Add(this.label38);
            this.panel3.Location = new System.Drawing.Point(12, 258);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 258);
            this.panel3.TabIndex = 2;
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TID,
            this.TeacherName,
            this.SHORT});
            this.listView2.Location = new System.Drawing.Point(22, 41);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(357, 202);
            this.listView2.TabIndex = 2;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // TID
            // 
            this.TID.Text = "TID";
            this.TID.Width = 51;
            // 
            // TeacherName
            // 
            this.TeacherName.Text = "Teacher Name";
            this.TeacherName.Width = 213;
            // 
            // SHORT
            // 
            this.SHORT.Text = "Short";
            this.SHORT.Width = 89;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(21, 14);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(180, 16);
            this.label38.TabIndex = 0;
            this.label38.Text = "Teachers Of Above Subjects";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(428, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(670, 511);
            this.panel1.TabIndex = 3;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(507, 187);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(148, 89);
            this.button4.TabIndex = 9;
            this.button4.Text = "CANCEL";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button3.Location = new System.Drawing.Point(507, 83);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 94);
            this.button3.TabIndex = 8;
            this.button3.Text = "SUBMIT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(158, 13);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(295, 31);
            this.label42.TabIndex = 5;
            this.label42.Text = "Add Time Table Details";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(42, 111);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(51, 16);
            this.label41.TabIndex = 4;
            this.label41.Text = "Shift     :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(42, 83);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(55, 16);
            this.label40.TabIndex = 3;
            this.label40.Text = "Year     :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(42, 53);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(56, 16);
            this.label39.TabIndex = 2;
            this.label39.Text = "Branch :";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Monday);
            this.tabControl1.Controls.Add(this.Tuesday);
            this.tabControl1.Controls.Add(this.Wednesday);
            this.tabControl1.Controls.Add(this.Thursday);
            this.tabControl1.Controls.Add(this.Friday);
            this.tabControl1.Controls.Add(this.Saturday);
            this.tabControl1.Location = new System.Drawing.Point(45, 150);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(417, 343);
            this.tabControl1.TabIndex = 1;
            // 
            // Monday
            // 
            this.Monday.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Monday.Controls.Add(this.monday62);
            this.Monday.Controls.Add(this.monday61);
            this.Monday.Controls.Add(this.label6);
            this.Monday.Controls.Add(this.monday52);
            this.Monday.Controls.Add(this.monday51);
            this.Monday.Controls.Add(this.label5);
            this.Monday.Controls.Add(this.monday42);
            this.Monday.Controls.Add(this.monday41);
            this.Monday.Controls.Add(this.label4);
            this.Monday.Controls.Add(this.monday32);
            this.Monday.Controls.Add(this.monday31);
            this.Monday.Controls.Add(this.label3);
            this.Monday.Controls.Add(this.monday22);
            this.Monday.Controls.Add(this.monday21);
            this.Monday.Controls.Add(this.label2);
            this.Monday.Controls.Add(this.monday12);
            this.Monday.Controls.Add(this.monday11);
            this.Monday.Controls.Add(this.label1);
            this.Monday.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Monday.Location = new System.Drawing.Point(4, 22);
            this.Monday.Name = "Monday";
            this.Monday.Padding = new System.Windows.Forms.Padding(30, 10, 30, 10);
            this.Monday.Size = new System.Drawing.Size(409, 317);
            this.Monday.TabIndex = 0;
            this.Monday.Text = "Monday";
            this.Monday.UseVisualStyleBackColor = true;
            // 
            // monday62
            // 
            this.monday62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday62.FormattingEnabled = true;
            this.monday62.Items.AddRange(new object[] {
            ""});
            this.monday62.Location = new System.Drawing.Point(257, 263);
            this.monday62.Name = "monday62";
            this.monday62.Size = new System.Drawing.Size(121, 28);
            this.monday62.TabIndex = 20;
            this.monday62.SelectedIndexChanged += new System.EventHandler(this.monday62_SelectedIndexChanged);
            // 
            // monday61
            // 
            this.monday61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday61.FormattingEnabled = true;
            this.monday61.Location = new System.Drawing.Point(129, 263);
            this.monday61.Name = "monday61";
            this.monday61.Size = new System.Drawing.Size(121, 28);
            this.monday61.TabIndex = 19;
            this.monday61.SelectedIndexChanged += new System.EventHandler(this.monday61_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(26, 266);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "LECTURE 6";
            // 
            // monday52
            // 
            this.monday52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday52.FormattingEnabled = true;
            this.monday52.Items.AddRange(new object[] {
            ""});
            this.monday52.Location = new System.Drawing.Point(257, 222);
            this.monday52.Name = "monday52";
            this.monday52.Size = new System.Drawing.Size(121, 28);
            this.monday52.TabIndex = 17;
            this.monday52.SelectedIndexChanged += new System.EventHandler(this.monday52_SelectedIndexChanged);
            // 
            // monday51
            // 
            this.monday51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday51.FormattingEnabled = true;
            this.monday51.Location = new System.Drawing.Point(129, 222);
            this.monday51.Name = "monday51";
            this.monday51.Size = new System.Drawing.Size(121, 28);
            this.monday51.TabIndex = 16;
            this.monday51.SelectedIndexChanged += new System.EventHandler(this.monday51_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(26, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "LECTURE 5";
            // 
            // monday42
            // 
            this.monday42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday42.FormattingEnabled = true;
            this.monday42.Items.AddRange(new object[] {
            ""});
            this.monday42.Location = new System.Drawing.Point(257, 181);
            this.monday42.Name = "monday42";
            this.monday42.Size = new System.Drawing.Size(121, 28);
            this.monday42.TabIndex = 14;
            this.monday42.SelectedIndexChanged += new System.EventHandler(this.monday42_SelectedIndexChanged);
            // 
            // monday41
            // 
            this.monday41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday41.FormattingEnabled = true;
            this.monday41.Location = new System.Drawing.Point(129, 181);
            this.monday41.Name = "monday41";
            this.monday41.Size = new System.Drawing.Size(121, 28);
            this.monday41.TabIndex = 13;
            this.monday41.SelectedIndexChanged += new System.EventHandler(this.monday41_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Location = new System.Drawing.Point(26, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "LECTURE 4";
            // 
            // monday32
            // 
            this.monday32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday32.FormattingEnabled = true;
            this.monday32.Items.AddRange(new object[] {
            ""});
            this.monday32.Location = new System.Drawing.Point(257, 140);
            this.monday32.Name = "monday32";
            this.monday32.Size = new System.Drawing.Size(121, 28);
            this.monday32.TabIndex = 11;
            this.monday32.SelectedIndexChanged += new System.EventHandler(this.monday32_SelectedIndexChanged);
            // 
            // monday31
            // 
            this.monday31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday31.FormattingEnabled = true;
            this.monday31.Location = new System.Drawing.Point(129, 140);
            this.monday31.Name = "monday31";
            this.monday31.Size = new System.Drawing.Size(121, 28);
            this.monday31.TabIndex = 10;
            this.monday31.SelectedIndexChanged += new System.EventHandler(this.monday31_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(26, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "LECTURE 3";
            // 
            // monday22
            // 
            this.monday22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday22.FormattingEnabled = true;
            this.monday22.Items.AddRange(new object[] {
            ""});
            this.monday22.Location = new System.Drawing.Point(257, 99);
            this.monday22.Name = "monday22";
            this.monday22.Size = new System.Drawing.Size(121, 28);
            this.monday22.TabIndex = 8;
            this.monday22.SelectedIndexChanged += new System.EventHandler(this.monday22_SelectedIndexChanged);
            // 
            // monday21
            // 
            this.monday21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday21.FormattingEnabled = true;
            this.monday21.Location = new System.Drawing.Point(129, 99);
            this.monday21.Name = "monday21";
            this.monday21.Size = new System.Drawing.Size(121, 28);
            this.monday21.TabIndex = 7;
            this.monday21.SelectedIndexChanged += new System.EventHandler(this.monday21_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(26, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "LECTURE 2";
            // 
            // monday12
            // 
            this.monday12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday12.FormattingEnabled = true;
            this.monday12.Items.AddRange(new object[] {
            ""});
            this.monday12.Location = new System.Drawing.Point(257, 56);
            this.monday12.Name = "monday12";
            this.monday12.Size = new System.Drawing.Size(121, 28);
            this.monday12.TabIndex = 5;
            this.monday12.SelectedIndexChanged += new System.EventHandler(this.monday12_SelectedIndexChanged);
            // 
            // monday11
            // 
            this.monday11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monday11.FormattingEnabled = true;
            this.monday11.Location = new System.Drawing.Point(129, 56);
            this.monday11.Name = "monday11";
            this.monday11.Size = new System.Drawing.Size(121, 28);
            this.monday11.TabIndex = 4;
            this.monday11.SelectedIndexChanged += new System.EventHandler(this.monday11_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(26, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "LECTURE 1";
            // 
            // Tuesday
            // 
            this.Tuesday.Controls.Add(this.tuesday62);
            this.Tuesday.Controls.Add(this.tuesday61);
            this.Tuesday.Controls.Add(this.label7);
            this.Tuesday.Controls.Add(this.tuesday52);
            this.Tuesday.Controls.Add(this.tuesday51);
            this.Tuesday.Controls.Add(this.label8);
            this.Tuesday.Controls.Add(this.tuesday42);
            this.Tuesday.Controls.Add(this.tuesday41);
            this.Tuesday.Controls.Add(this.label9);
            this.Tuesday.Controls.Add(this.tuesday32);
            this.Tuesday.Controls.Add(this.tuesday31);
            this.Tuesday.Controls.Add(this.label10);
            this.Tuesday.Controls.Add(this.tuesday22);
            this.Tuesday.Controls.Add(this.tuesday21);
            this.Tuesday.Controls.Add(this.label11);
            this.Tuesday.Controls.Add(this.tuesday12);
            this.Tuesday.Controls.Add(this.tuesday11);
            this.Tuesday.Controls.Add(this.label12);
            this.Tuesday.Location = new System.Drawing.Point(4, 22);
            this.Tuesday.Name = "Tuesday";
            this.Tuesday.Padding = new System.Windows.Forms.Padding(30, 10, 30, 10);
            this.Tuesday.Size = new System.Drawing.Size(409, 317);
            this.Tuesday.TabIndex = 1;
            this.Tuesday.Text = "Tuesday";
            this.Tuesday.UseVisualStyleBackColor = true;
            // 
            // tuesday62
            // 
            this.tuesday62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday62.FormattingEnabled = true;
            this.tuesday62.Items.AddRange(new object[] {
            ""});
            this.tuesday62.Location = new System.Drawing.Point(253, 267);
            this.tuesday62.Name = "tuesday62";
            this.tuesday62.Size = new System.Drawing.Size(121, 28);
            this.tuesday62.TabIndex = 38;
            this.tuesday62.SelectedIndexChanged += new System.EventHandler(this.tuesday62_SelectedIndexChanged);
            // 
            // tuesday61
            // 
            this.tuesday61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday61.FormattingEnabled = true;
            this.tuesday61.Location = new System.Drawing.Point(125, 267);
            this.tuesday61.Name = "tuesday61";
            this.tuesday61.Size = new System.Drawing.Size(121, 28);
            this.tuesday61.TabIndex = 37;
            this.tuesday61.SelectedIndexChanged += new System.EventHandler(this.tuesday61_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(22, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "LECTURE 6";
            // 
            // tuesday52
            // 
            this.tuesday52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday52.FormattingEnabled = true;
            this.tuesday52.Items.AddRange(new object[] {
            ""});
            this.tuesday52.Location = new System.Drawing.Point(253, 226);
            this.tuesday52.Name = "tuesday52";
            this.tuesday52.Size = new System.Drawing.Size(121, 28);
            this.tuesday52.TabIndex = 35;
            this.tuesday52.SelectedIndexChanged += new System.EventHandler(this.tuesday52_SelectedIndexChanged);
            // 
            // tuesday51
            // 
            this.tuesday51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday51.FormattingEnabled = true;
            this.tuesday51.Location = new System.Drawing.Point(125, 226);
            this.tuesday51.Name = "tuesday51";
            this.tuesday51.Size = new System.Drawing.Size(121, 28);
            this.tuesday51.TabIndex = 34;
            this.tuesday51.SelectedIndexChanged += new System.EventHandler(this.tuesday51_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label8.Location = new System.Drawing.Point(22, 227);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "LECTURE 5";
            // 
            // tuesday42
            // 
            this.tuesday42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday42.FormattingEnabled = true;
            this.tuesday42.Items.AddRange(new object[] {
            ""});
            this.tuesday42.Location = new System.Drawing.Point(253, 185);
            this.tuesday42.Name = "tuesday42";
            this.tuesday42.Size = new System.Drawing.Size(121, 28);
            this.tuesday42.TabIndex = 32;
            this.tuesday42.SelectedIndexChanged += new System.EventHandler(this.tuesday42_SelectedIndexChanged);
            // 
            // tuesday41
            // 
            this.tuesday41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday41.FormattingEnabled = true;
            this.tuesday41.Location = new System.Drawing.Point(125, 185);
            this.tuesday41.Name = "tuesday41";
            this.tuesday41.Size = new System.Drawing.Size(121, 28);
            this.tuesday41.TabIndex = 31;
            this.tuesday41.SelectedIndexChanged += new System.EventHandler(this.tuesday41_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(22, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 20);
            this.label9.TabIndex = 30;
            this.label9.Text = "LECTURE 4";
            // 
            // tuesday32
            // 
            this.tuesday32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday32.FormattingEnabled = true;
            this.tuesday32.Items.AddRange(new object[] {
            ""});
            this.tuesday32.Location = new System.Drawing.Point(253, 144);
            this.tuesday32.Name = "tuesday32";
            this.tuesday32.Size = new System.Drawing.Size(121, 28);
            this.tuesday32.TabIndex = 29;
            this.tuesday32.SelectedIndexChanged += new System.EventHandler(this.tuesday32_SelectedIndexChanged);
            // 
            // tuesday31
            // 
            this.tuesday31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday31.FormattingEnabled = true;
            this.tuesday31.Location = new System.Drawing.Point(125, 144);
            this.tuesday31.Name = "tuesday31";
            this.tuesday31.Size = new System.Drawing.Size(121, 28);
            this.tuesday31.TabIndex = 28;
            this.tuesday31.SelectedIndexChanged += new System.EventHandler(this.tuesday31_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label10.Location = new System.Drawing.Point(22, 145);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 20);
            this.label10.TabIndex = 27;
            this.label10.Text = "LECTURE 3";
            // 
            // tuesday22
            // 
            this.tuesday22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday22.FormattingEnabled = true;
            this.tuesday22.Items.AddRange(new object[] {
            ""});
            this.tuesday22.Location = new System.Drawing.Point(253, 103);
            this.tuesday22.Name = "tuesday22";
            this.tuesday22.Size = new System.Drawing.Size(121, 28);
            this.tuesday22.TabIndex = 26;
            this.tuesday22.SelectedIndexChanged += new System.EventHandler(this.tuesday22_SelectedIndexChanged);
            // 
            // tuesday21
            // 
            this.tuesday21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday21.FormattingEnabled = true;
            this.tuesday21.Location = new System.Drawing.Point(125, 103);
            this.tuesday21.Name = "tuesday21";
            this.tuesday21.Size = new System.Drawing.Size(121, 28);
            this.tuesday21.TabIndex = 25;
            this.tuesday21.SelectedIndexChanged += new System.EventHandler(this.tuesday21_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(22, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 20);
            this.label11.TabIndex = 24;
            this.label11.Text = "LECTURE 2";
            // 
            // tuesday12
            // 
            this.tuesday12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday12.FormattingEnabled = true;
            this.tuesday12.Items.AddRange(new object[] {
            ""});
            this.tuesday12.Location = new System.Drawing.Point(253, 60);
            this.tuesday12.Name = "tuesday12";
            this.tuesday12.Size = new System.Drawing.Size(121, 28);
            this.tuesday12.TabIndex = 23;
            this.tuesday12.SelectedIndexChanged += new System.EventHandler(this.tuesday12_SelectedIndexChanged);
            // 
            // tuesday11
            // 
            this.tuesday11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuesday11.FormattingEnabled = true;
            this.tuesday11.Location = new System.Drawing.Point(125, 60);
            this.tuesday11.Name = "tuesday11";
            this.tuesday11.Size = new System.Drawing.Size(121, 28);
            this.tuesday11.TabIndex = 22;
            this.tuesday11.SelectedIndexChanged += new System.EventHandler(this.tuesday11_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(22, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 20);
            this.label12.TabIndex = 21;
            this.label12.Text = "LECTURE 1";
            // 
            // Wednesday
            // 
            this.Wednesday.Controls.Add(this.wednesday62);
            this.Wednesday.Controls.Add(this.wednesday61);
            this.Wednesday.Controls.Add(this.label13);
            this.Wednesday.Controls.Add(this.wednesday52);
            this.Wednesday.Controls.Add(this.wednesday51);
            this.Wednesday.Controls.Add(this.label14);
            this.Wednesday.Controls.Add(this.wednesday42);
            this.Wednesday.Controls.Add(this.wednesday41);
            this.Wednesday.Controls.Add(this.label15);
            this.Wednesday.Controls.Add(this.wednesday32);
            this.Wednesday.Controls.Add(this.wednesday31);
            this.Wednesday.Controls.Add(this.label16);
            this.Wednesday.Controls.Add(this.wednesday22);
            this.Wednesday.Controls.Add(this.wednesday21);
            this.Wednesday.Controls.Add(this.label17);
            this.Wednesday.Controls.Add(this.wednesday12);
            this.Wednesday.Controls.Add(this.wednesday11);
            this.Wednesday.Controls.Add(this.label18);
            this.Wednesday.Location = new System.Drawing.Point(4, 22);
            this.Wednesday.Name = "Wednesday";
            this.Wednesday.Padding = new System.Windows.Forms.Padding(30, 10, 30, 10);
            this.Wednesday.Size = new System.Drawing.Size(409, 317);
            this.Wednesday.TabIndex = 2;
            this.Wednesday.Text = "Wednesday";
            this.Wednesday.UseVisualStyleBackColor = true;
            // 
            // wednesday62
            // 
            this.wednesday62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday62.FormattingEnabled = true;
            this.wednesday62.Items.AddRange(new object[] {
            ""});
            this.wednesday62.Location = new System.Drawing.Point(259, 262);
            this.wednesday62.Name = "wednesday62";
            this.wednesday62.Size = new System.Drawing.Size(121, 28);
            this.wednesday62.TabIndex = 38;
            this.wednesday62.SelectedIndexChanged += new System.EventHandler(this.wednesday62_SelectedIndexChanged);
            // 
            // wednesday61
            // 
            this.wednesday61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday61.FormattingEnabled = true;
            this.wednesday61.Location = new System.Drawing.Point(131, 262);
            this.wednesday61.Name = "wednesday61";
            this.wednesday61.Size = new System.Drawing.Size(121, 28);
            this.wednesday61.TabIndex = 37;
            this.wednesday61.SelectedIndexChanged += new System.EventHandler(this.wednesday61_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label13.Location = new System.Drawing.Point(28, 265);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 20);
            this.label13.TabIndex = 36;
            this.label13.Text = "LECTURE 6";
            // 
            // wednesday52
            // 
            this.wednesday52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday52.FormattingEnabled = true;
            this.wednesday52.Items.AddRange(new object[] {
            ""});
            this.wednesday52.Location = new System.Drawing.Point(259, 221);
            this.wednesday52.Name = "wednesday52";
            this.wednesday52.Size = new System.Drawing.Size(121, 28);
            this.wednesday52.TabIndex = 35;
            this.wednesday52.SelectedIndexChanged += new System.EventHandler(this.wednesday52_SelectedIndexChanged);
            // 
            // wednesday51
            // 
            this.wednesday51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday51.FormattingEnabled = true;
            this.wednesday51.Location = new System.Drawing.Point(131, 221);
            this.wednesday51.Name = "wednesday51";
            this.wednesday51.Size = new System.Drawing.Size(121, 28);
            this.wednesday51.TabIndex = 34;
            this.wednesday51.SelectedIndexChanged += new System.EventHandler(this.wednesday51_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label14.Location = new System.Drawing.Point(28, 224);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 20);
            this.label14.TabIndex = 33;
            this.label14.Text = "LECTURE 5";
            // 
            // wednesday42
            // 
            this.wednesday42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday42.FormattingEnabled = true;
            this.wednesday42.Items.AddRange(new object[] {
            ""});
            this.wednesday42.Location = new System.Drawing.Point(259, 180);
            this.wednesday42.Name = "wednesday42";
            this.wednesday42.Size = new System.Drawing.Size(121, 28);
            this.wednesday42.TabIndex = 32;
            this.wednesday42.SelectedIndexChanged += new System.EventHandler(this.wednesday42_SelectedIndexChanged);
            // 
            // wednesday41
            // 
            this.wednesday41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday41.FormattingEnabled = true;
            this.wednesday41.Location = new System.Drawing.Point(131, 180);
            this.wednesday41.Name = "wednesday41";
            this.wednesday41.Size = new System.Drawing.Size(121, 28);
            this.wednesday41.TabIndex = 31;
            this.wednesday41.SelectedIndexChanged += new System.EventHandler(this.wednesday41_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label15.Location = new System.Drawing.Point(28, 183);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "LECTURE 4";
            // 
            // wednesday32
            // 
            this.wednesday32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday32.FormattingEnabled = true;
            this.wednesday32.Items.AddRange(new object[] {
            ""});
            this.wednesday32.Location = new System.Drawing.Point(259, 139);
            this.wednesday32.Name = "wednesday32";
            this.wednesday32.Size = new System.Drawing.Size(121, 28);
            this.wednesday32.TabIndex = 29;
            this.wednesday32.SelectedIndexChanged += new System.EventHandler(this.wednesday32_SelectedIndexChanged);
            // 
            // wednesday31
            // 
            this.wednesday31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday31.FormattingEnabled = true;
            this.wednesday31.Location = new System.Drawing.Point(131, 139);
            this.wednesday31.Name = "wednesday31";
            this.wednesday31.Size = new System.Drawing.Size(121, 28);
            this.wednesday31.TabIndex = 28;
            this.wednesday31.SelectedIndexChanged += new System.EventHandler(this.wednesday31_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label16.Location = new System.Drawing.Point(28, 142);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 20);
            this.label16.TabIndex = 27;
            this.label16.Text = "LECTURE 3";
            // 
            // wednesday22
            // 
            this.wednesday22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday22.FormattingEnabled = true;
            this.wednesday22.Items.AddRange(new object[] {
            ""});
            this.wednesday22.Location = new System.Drawing.Point(259, 98);
            this.wednesday22.Name = "wednesday22";
            this.wednesday22.Size = new System.Drawing.Size(121, 28);
            this.wednesday22.TabIndex = 26;
            this.wednesday22.SelectedIndexChanged += new System.EventHandler(this.wednesday22_SelectedIndexChanged);
            // 
            // wednesday21
            // 
            this.wednesday21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday21.FormattingEnabled = true;
            this.wednesday21.Location = new System.Drawing.Point(131, 98);
            this.wednesday21.Name = "wednesday21";
            this.wednesday21.Size = new System.Drawing.Size(121, 28);
            this.wednesday21.TabIndex = 25;
            this.wednesday21.SelectedIndexChanged += new System.EventHandler(this.wednesday21_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label17.Location = new System.Drawing.Point(28, 101);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(97, 20);
            this.label17.TabIndex = 24;
            this.label17.Text = "LECTURE 2";
            // 
            // wednesday12
            // 
            this.wednesday12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday12.FormattingEnabled = true;
            this.wednesday12.Items.AddRange(new object[] {
            ""});
            this.wednesday12.Location = new System.Drawing.Point(259, 55);
            this.wednesday12.Name = "wednesday12";
            this.wednesday12.Size = new System.Drawing.Size(121, 28);
            this.wednesday12.TabIndex = 23;
            this.wednesday12.SelectedIndexChanged += new System.EventHandler(this.wednesday12_SelectedIndexChanged);
            // 
            // wednesday11
            // 
            this.wednesday11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wednesday11.FormattingEnabled = true;
            this.wednesday11.Location = new System.Drawing.Point(131, 55);
            this.wednesday11.Name = "wednesday11";
            this.wednesday11.Size = new System.Drawing.Size(121, 28);
            this.wednesday11.TabIndex = 22;
            this.wednesday11.SelectedIndexChanged += new System.EventHandler(this.wednesday11_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label18.Location = new System.Drawing.Point(28, 58);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(97, 20);
            this.label18.TabIndex = 21;
            this.label18.Text = "LECTURE 1";
            // 
            // Thursday
            // 
            this.Thursday.Controls.Add(this.thursday62);
            this.Thursday.Controls.Add(this.thursday61);
            this.Thursday.Controls.Add(this.label19);
            this.Thursday.Controls.Add(this.thursday52);
            this.Thursday.Controls.Add(this.thursday51);
            this.Thursday.Controls.Add(this.label20);
            this.Thursday.Controls.Add(this.thursday42);
            this.Thursday.Controls.Add(this.thursday41);
            this.Thursday.Controls.Add(this.label21);
            this.Thursday.Controls.Add(this.thursday32);
            this.Thursday.Controls.Add(this.thursday31);
            this.Thursday.Controls.Add(this.label22);
            this.Thursday.Controls.Add(this.thursday22);
            this.Thursday.Controls.Add(this.thursday21);
            this.Thursday.Controls.Add(this.label23);
            this.Thursday.Controls.Add(this.thursday12);
            this.Thursday.Controls.Add(this.thursday11);
            this.Thursday.Controls.Add(this.label24);
            this.Thursday.Location = new System.Drawing.Point(4, 22);
            this.Thursday.Name = "Thursday";
            this.Thursday.Padding = new System.Windows.Forms.Padding(30, 10, 30, 10);
            this.Thursday.Size = new System.Drawing.Size(409, 317);
            this.Thursday.TabIndex = 3;
            this.Thursday.Text = "Thursday";
            this.Thursday.UseVisualStyleBackColor = true;
            // 
            // thursday62
            // 
            this.thursday62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday62.FormattingEnabled = true;
            this.thursday62.Items.AddRange(new object[] {
            ""});
            this.thursday62.Location = new System.Drawing.Point(259, 262);
            this.thursday62.Name = "thursday62";
            this.thursday62.Size = new System.Drawing.Size(121, 28);
            this.thursday62.TabIndex = 38;
            this.thursday62.SelectedIndexChanged += new System.EventHandler(this.thursday62_SelectedIndexChanged);
            // 
            // thursday61
            // 
            this.thursday61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday61.FormattingEnabled = true;
            this.thursday61.Location = new System.Drawing.Point(131, 262);
            this.thursday61.Name = "thursday61";
            this.thursday61.Size = new System.Drawing.Size(121, 28);
            this.thursday61.TabIndex = 37;
            this.thursday61.SelectedIndexChanged += new System.EventHandler(this.thursday61_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label19.Location = new System.Drawing.Point(28, 265);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 20);
            this.label19.TabIndex = 36;
            this.label19.Text = "LECTURE 6";
            // 
            // thursday52
            // 
            this.thursday52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday52.FormattingEnabled = true;
            this.thursday52.Items.AddRange(new object[] {
            ""});
            this.thursday52.Location = new System.Drawing.Point(259, 221);
            this.thursday52.Name = "thursday52";
            this.thursday52.Size = new System.Drawing.Size(121, 28);
            this.thursday52.TabIndex = 35;
            this.thursday52.SelectedIndexChanged += new System.EventHandler(this.thursday52_SelectedIndexChanged);
            // 
            // thursday51
            // 
            this.thursday51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday51.FormattingEnabled = true;
            this.thursday51.Location = new System.Drawing.Point(131, 221);
            this.thursday51.Name = "thursday51";
            this.thursday51.Size = new System.Drawing.Size(121, 28);
            this.thursday51.TabIndex = 34;
            this.thursday51.SelectedIndexChanged += new System.EventHandler(this.thursday51_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label20.Location = new System.Drawing.Point(28, 224);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(97, 20);
            this.label20.TabIndex = 33;
            this.label20.Text = "LECTURE 5";
            // 
            // thursday42
            // 
            this.thursday42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday42.FormattingEnabled = true;
            this.thursday42.Items.AddRange(new object[] {
            ""});
            this.thursday42.Location = new System.Drawing.Point(259, 180);
            this.thursday42.Name = "thursday42";
            this.thursday42.Size = new System.Drawing.Size(121, 28);
            this.thursday42.TabIndex = 32;
            this.thursday42.SelectedIndexChanged += new System.EventHandler(this.thursday42_SelectedIndexChanged);
            // 
            // thursday41
            // 
            this.thursday41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday41.FormattingEnabled = true;
            this.thursday41.Location = new System.Drawing.Point(131, 180);
            this.thursday41.Name = "thursday41";
            this.thursday41.Size = new System.Drawing.Size(121, 28);
            this.thursday41.TabIndex = 31;
            this.thursday41.SelectedIndexChanged += new System.EventHandler(this.thursday41_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label21.Location = new System.Drawing.Point(28, 183);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(97, 20);
            this.label21.TabIndex = 30;
            this.label21.Text = "LECTURE 4";
            // 
            // thursday32
            // 
            this.thursday32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday32.FormattingEnabled = true;
            this.thursday32.Items.AddRange(new object[] {
            ""});
            this.thursday32.Location = new System.Drawing.Point(259, 139);
            this.thursday32.Name = "thursday32";
            this.thursday32.Size = new System.Drawing.Size(121, 28);
            this.thursday32.TabIndex = 29;
            this.thursday32.SelectedIndexChanged += new System.EventHandler(this.thursday32_SelectedIndexChanged);
            // 
            // thursday31
            // 
            this.thursday31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday31.FormattingEnabled = true;
            this.thursday31.Location = new System.Drawing.Point(131, 139);
            this.thursday31.Name = "thursday31";
            this.thursday31.Size = new System.Drawing.Size(121, 28);
            this.thursday31.TabIndex = 28;
            this.thursday31.SelectedIndexChanged += new System.EventHandler(this.thursday31_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label22.Location = new System.Drawing.Point(28, 142);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(97, 20);
            this.label22.TabIndex = 27;
            this.label22.Text = "LECTURE 3";
            // 
            // thursday22
            // 
            this.thursday22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday22.FormattingEnabled = true;
            this.thursday22.Items.AddRange(new object[] {
            ""});
            this.thursday22.Location = new System.Drawing.Point(259, 98);
            this.thursday22.Name = "thursday22";
            this.thursday22.Size = new System.Drawing.Size(121, 28);
            this.thursday22.TabIndex = 26;
            this.thursday22.SelectedIndexChanged += new System.EventHandler(this.thursday22_SelectedIndexChanged);
            // 
            // thursday21
            // 
            this.thursday21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday21.FormattingEnabled = true;
            this.thursday21.Location = new System.Drawing.Point(131, 98);
            this.thursday21.Name = "thursday21";
            this.thursday21.Size = new System.Drawing.Size(121, 28);
            this.thursday21.TabIndex = 25;
            this.thursday21.SelectedIndexChanged += new System.EventHandler(this.thursday21_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label23.Location = new System.Drawing.Point(28, 101);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(97, 20);
            this.label23.TabIndex = 24;
            this.label23.Text = "LECTURE 2";
            // 
            // thursday12
            // 
            this.thursday12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday12.FormattingEnabled = true;
            this.thursday12.Items.AddRange(new object[] {
            ""});
            this.thursday12.Location = new System.Drawing.Point(259, 55);
            this.thursday12.Name = "thursday12";
            this.thursday12.Size = new System.Drawing.Size(121, 28);
            this.thursday12.TabIndex = 23;
            this.thursday12.SelectedIndexChanged += new System.EventHandler(this.thursday12_SelectedIndexChanged);
            // 
            // thursday11
            // 
            this.thursday11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thursday11.FormattingEnabled = true;
            this.thursday11.Location = new System.Drawing.Point(131, 55);
            this.thursday11.Name = "thursday11";
            this.thursday11.Size = new System.Drawing.Size(121, 28);
            this.thursday11.TabIndex = 22;
            this.thursday11.SelectedIndexChanged += new System.EventHandler(this.thursday11_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label24.Location = new System.Drawing.Point(28, 58);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(97, 20);
            this.label24.TabIndex = 21;
            this.label24.Text = "LECTURE 1";
            // 
            // Friday
            // 
            this.Friday.Controls.Add(this.friday62);
            this.Friday.Controls.Add(this.friday61);
            this.Friday.Controls.Add(this.label25);
            this.Friday.Controls.Add(this.friday52);
            this.Friday.Controls.Add(this.friday51);
            this.Friday.Controls.Add(this.label26);
            this.Friday.Controls.Add(this.friday42);
            this.Friday.Controls.Add(this.friday41);
            this.Friday.Controls.Add(this.label27);
            this.Friday.Controls.Add(this.friday32);
            this.Friday.Controls.Add(this.friday31);
            this.Friday.Controls.Add(this.label28);
            this.Friday.Controls.Add(this.friday22);
            this.Friday.Controls.Add(this.friday21);
            this.Friday.Controls.Add(this.label29);
            this.Friday.Controls.Add(this.friday12);
            this.Friday.Controls.Add(this.friday11);
            this.Friday.Controls.Add(this.label30);
            this.Friday.Location = new System.Drawing.Point(4, 22);
            this.Friday.Name = "Friday";
            this.Friday.Padding = new System.Windows.Forms.Padding(30, 10, 30, 10);
            this.Friday.Size = new System.Drawing.Size(409, 317);
            this.Friday.TabIndex = 4;
            this.Friday.Text = "Friday";
            this.Friday.UseVisualStyleBackColor = true;
            // 
            // friday62
            // 
            this.friday62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday62.FormattingEnabled = true;
            this.friday62.Items.AddRange(new object[] {
            ""});
            this.friday62.Location = new System.Drawing.Point(259, 262);
            this.friday62.Name = "friday62";
            this.friday62.Size = new System.Drawing.Size(121, 28);
            this.friday62.TabIndex = 38;
            this.friday62.SelectedIndexChanged += new System.EventHandler(this.friday62_SelectedIndexChanged);
            // 
            // friday61
            // 
            this.friday61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday61.FormattingEnabled = true;
            this.friday61.Location = new System.Drawing.Point(131, 262);
            this.friday61.Name = "friday61";
            this.friday61.Size = new System.Drawing.Size(121, 28);
            this.friday61.TabIndex = 37;
            this.friday61.SelectedIndexChanged += new System.EventHandler(this.friday61_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label25.Location = new System.Drawing.Point(28, 265);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(97, 20);
            this.label25.TabIndex = 36;
            this.label25.Text = "LECTURE 6";
            // 
            // friday52
            // 
            this.friday52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday52.FormattingEnabled = true;
            this.friday52.Items.AddRange(new object[] {
            ""});
            this.friday52.Location = new System.Drawing.Point(259, 221);
            this.friday52.Name = "friday52";
            this.friday52.Size = new System.Drawing.Size(121, 28);
            this.friday52.TabIndex = 35;
            this.friday52.SelectedIndexChanged += new System.EventHandler(this.friday52_SelectedIndexChanged);
            // 
            // friday51
            // 
            this.friday51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday51.FormattingEnabled = true;
            this.friday51.Location = new System.Drawing.Point(131, 221);
            this.friday51.Name = "friday51";
            this.friday51.Size = new System.Drawing.Size(121, 28);
            this.friday51.TabIndex = 34;
            this.friday51.SelectedIndexChanged += new System.EventHandler(this.friday51_SelectedIndexChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label26.Location = new System.Drawing.Point(28, 224);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(97, 20);
            this.label26.TabIndex = 33;
            this.label26.Text = "LECTURE 5";
            // 
            // friday42
            // 
            this.friday42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday42.FormattingEnabled = true;
            this.friday42.Items.AddRange(new object[] {
            ""});
            this.friday42.Location = new System.Drawing.Point(259, 180);
            this.friday42.Name = "friday42";
            this.friday42.Size = new System.Drawing.Size(121, 28);
            this.friday42.TabIndex = 32;
            this.friday42.SelectedIndexChanged += new System.EventHandler(this.friday42_SelectedIndexChanged);
            // 
            // friday41
            // 
            this.friday41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday41.FormattingEnabled = true;
            this.friday41.Location = new System.Drawing.Point(131, 180);
            this.friday41.Name = "friday41";
            this.friday41.Size = new System.Drawing.Size(121, 28);
            this.friday41.TabIndex = 31;
            this.friday41.SelectedIndexChanged += new System.EventHandler(this.friday41_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label27.Location = new System.Drawing.Point(28, 183);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(97, 20);
            this.label27.TabIndex = 30;
            this.label27.Text = "LECTURE 4";
            // 
            // friday32
            // 
            this.friday32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday32.FormattingEnabled = true;
            this.friday32.Items.AddRange(new object[] {
            ""});
            this.friday32.Location = new System.Drawing.Point(259, 139);
            this.friday32.Name = "friday32";
            this.friday32.Size = new System.Drawing.Size(121, 28);
            this.friday32.TabIndex = 29;
            this.friday32.SelectedIndexChanged += new System.EventHandler(this.friday32_SelectedIndexChanged);
            // 
            // friday31
            // 
            this.friday31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday31.FormattingEnabled = true;
            this.friday31.Location = new System.Drawing.Point(131, 139);
            this.friday31.Name = "friday31";
            this.friday31.Size = new System.Drawing.Size(121, 28);
            this.friday31.TabIndex = 28;
            this.friday31.SelectedIndexChanged += new System.EventHandler(this.friday31_SelectedIndexChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label28.Location = new System.Drawing.Point(28, 142);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(97, 20);
            this.label28.TabIndex = 27;
            this.label28.Text = "LECTURE 3";
            // 
            // friday22
            // 
            this.friday22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday22.FormattingEnabled = true;
            this.friday22.Items.AddRange(new object[] {
            ""});
            this.friday22.Location = new System.Drawing.Point(259, 98);
            this.friday22.Name = "friday22";
            this.friday22.Size = new System.Drawing.Size(121, 28);
            this.friday22.TabIndex = 26;
            this.friday22.SelectedIndexChanged += new System.EventHandler(this.friday22_SelectedIndexChanged);
            // 
            // friday21
            // 
            this.friday21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday21.FormattingEnabled = true;
            this.friday21.Location = new System.Drawing.Point(131, 98);
            this.friday21.Name = "friday21";
            this.friday21.Size = new System.Drawing.Size(121, 28);
            this.friday21.TabIndex = 25;
            this.friday21.SelectedIndexChanged += new System.EventHandler(this.friday21_SelectedIndexChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label29.Location = new System.Drawing.Point(28, 101);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(97, 20);
            this.label29.TabIndex = 24;
            this.label29.Text = "LECTURE 2";
            // 
            // friday12
            // 
            this.friday12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday12.FormattingEnabled = true;
            this.friday12.Items.AddRange(new object[] {
            ""});
            this.friday12.Location = new System.Drawing.Point(259, 55);
            this.friday12.Name = "friday12";
            this.friday12.Size = new System.Drawing.Size(121, 28);
            this.friday12.TabIndex = 23;
            this.friday12.SelectedIndexChanged += new System.EventHandler(this.friday12_SelectedIndexChanged);
            // 
            // friday11
            // 
            this.friday11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friday11.FormattingEnabled = true;
            this.friday11.Location = new System.Drawing.Point(131, 55);
            this.friday11.Name = "friday11";
            this.friday11.Size = new System.Drawing.Size(121, 28);
            this.friday11.TabIndex = 22;
            this.friday11.SelectedIndexChanged += new System.EventHandler(this.friday11_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label30.Location = new System.Drawing.Point(28, 58);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(97, 20);
            this.label30.TabIndex = 21;
            this.label30.Text = "LECTURE 1";
            // 
            // Saturday
            // 
            this.Saturday.Controls.Add(this.saturday62);
            this.Saturday.Controls.Add(this.saturday61);
            this.Saturday.Controls.Add(this.label31);
            this.Saturday.Controls.Add(this.saturday52);
            this.Saturday.Controls.Add(this.saturday51);
            this.Saturday.Controls.Add(this.label32);
            this.Saturday.Controls.Add(this.saturday42);
            this.Saturday.Controls.Add(this.saturday41);
            this.Saturday.Controls.Add(this.label33);
            this.Saturday.Controls.Add(this.saturday32);
            this.Saturday.Controls.Add(this.saturday31);
            this.Saturday.Controls.Add(this.label34);
            this.Saturday.Controls.Add(this.saturday22);
            this.Saturday.Controls.Add(this.saturday21);
            this.Saturday.Controls.Add(this.label35);
            this.Saturday.Controls.Add(this.saturday12);
            this.Saturday.Controls.Add(this.saturday11);
            this.Saturday.Controls.Add(this.label36);
            this.Saturday.Location = new System.Drawing.Point(4, 22);
            this.Saturday.Name = "Saturday";
            this.Saturday.Padding = new System.Windows.Forms.Padding(30, 10, 30, 10);
            this.Saturday.Size = new System.Drawing.Size(409, 317);
            this.Saturday.TabIndex = 5;
            this.Saturday.Text = "Saturday";
            this.Saturday.UseVisualStyleBackColor = true;
            // 
            // saturday62
            // 
            this.saturday62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday62.FormattingEnabled = true;
            this.saturday62.Items.AddRange(new object[] {
            ""});
            this.saturday62.Location = new System.Drawing.Point(259, 262);
            this.saturday62.Name = "saturday62";
            this.saturday62.Size = new System.Drawing.Size(121, 28);
            this.saturday62.TabIndex = 38;
            this.saturday62.SelectedIndexChanged += new System.EventHandler(this.saturday62_SelectedIndexChanged);
            // 
            // saturday61
            // 
            this.saturday61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday61.FormattingEnabled = true;
            this.saturday61.Location = new System.Drawing.Point(131, 262);
            this.saturday61.Name = "saturday61";
            this.saturday61.Size = new System.Drawing.Size(121, 28);
            this.saturday61.TabIndex = 37;
            this.saturday61.SelectedIndexChanged += new System.EventHandler(this.saturday61_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label31.Location = new System.Drawing.Point(28, 265);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(97, 20);
            this.label31.TabIndex = 36;
            this.label31.Text = "LECTURE 6";
            // 
            // saturday52
            // 
            this.saturday52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday52.FormattingEnabled = true;
            this.saturday52.Items.AddRange(new object[] {
            ""});
            this.saturday52.Location = new System.Drawing.Point(259, 221);
            this.saturday52.Name = "saturday52";
            this.saturday52.Size = new System.Drawing.Size(121, 28);
            this.saturday52.TabIndex = 35;
            this.saturday52.SelectedIndexChanged += new System.EventHandler(this.saturday52_SelectedIndexChanged);
            // 
            // saturday51
            // 
            this.saturday51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday51.FormattingEnabled = true;
            this.saturday51.Location = new System.Drawing.Point(131, 221);
            this.saturday51.Name = "saturday51";
            this.saturday51.Size = new System.Drawing.Size(121, 28);
            this.saturday51.TabIndex = 34;
            this.saturday51.SelectedIndexChanged += new System.EventHandler(this.saturday51_SelectedIndexChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label32.Location = new System.Drawing.Point(28, 224);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(97, 20);
            this.label32.TabIndex = 33;
            this.label32.Text = "LECTURE 5";
            // 
            // saturday42
            // 
            this.saturday42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday42.FormattingEnabled = true;
            this.saturday42.Items.AddRange(new object[] {
            ""});
            this.saturday42.Location = new System.Drawing.Point(259, 180);
            this.saturday42.Name = "saturday42";
            this.saturday42.Size = new System.Drawing.Size(121, 28);
            this.saturday42.TabIndex = 32;
            this.saturday42.SelectedIndexChanged += new System.EventHandler(this.saturday42_SelectedIndexChanged);
            // 
            // saturday41
            // 
            this.saturday41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday41.FormattingEnabled = true;
            this.saturday41.Location = new System.Drawing.Point(131, 180);
            this.saturday41.Name = "saturday41";
            this.saturday41.Size = new System.Drawing.Size(121, 28);
            this.saturday41.TabIndex = 31;
            this.saturday41.SelectedIndexChanged += new System.EventHandler(this.saturday41_SelectedIndexChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label33.Location = new System.Drawing.Point(28, 183);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(97, 20);
            this.label33.TabIndex = 30;
            this.label33.Text = "LECTURE 4";
            // 
            // saturday32
            // 
            this.saturday32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday32.FormattingEnabled = true;
            this.saturday32.Items.AddRange(new object[] {
            ""});
            this.saturday32.Location = new System.Drawing.Point(259, 139);
            this.saturday32.Name = "saturday32";
            this.saturday32.Size = new System.Drawing.Size(121, 28);
            this.saturday32.TabIndex = 29;
            this.saturday32.SelectedIndexChanged += new System.EventHandler(this.saturday32_SelectedIndexChanged);
            // 
            // saturday31
            // 
            this.saturday31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday31.FormattingEnabled = true;
            this.saturday31.Location = new System.Drawing.Point(131, 139);
            this.saturday31.Name = "saturday31";
            this.saturday31.Size = new System.Drawing.Size(121, 28);
            this.saturday31.TabIndex = 28;
            this.saturday31.SelectedIndexChanged += new System.EventHandler(this.saturday31_SelectedIndexChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label34.Location = new System.Drawing.Point(28, 142);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(97, 20);
            this.label34.TabIndex = 27;
            this.label34.Text = "LECTURE 3";
            // 
            // saturday22
            // 
            this.saturday22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday22.FormattingEnabled = true;
            this.saturday22.Items.AddRange(new object[] {
            ""});
            this.saturday22.Location = new System.Drawing.Point(259, 98);
            this.saturday22.Name = "saturday22";
            this.saturday22.Size = new System.Drawing.Size(121, 28);
            this.saturday22.TabIndex = 26;
            this.saturday22.SelectedIndexChanged += new System.EventHandler(this.saturday22_SelectedIndexChanged);
            // 
            // saturday21
            // 
            this.saturday21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday21.FormattingEnabled = true;
            this.saturday21.Location = new System.Drawing.Point(131, 98);
            this.saturday21.Name = "saturday21";
            this.saturday21.Size = new System.Drawing.Size(121, 28);
            this.saturday21.TabIndex = 25;
            this.saturday21.SelectedIndexChanged += new System.EventHandler(this.saturday21_SelectedIndexChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label35.Location = new System.Drawing.Point(28, 101);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(97, 20);
            this.label35.TabIndex = 24;
            this.label35.Text = "LECTURE 2";
            // 
            // saturday12
            // 
            this.saturday12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday12.FormattingEnabled = true;
            this.saturday12.Items.AddRange(new object[] {
            ""});
            this.saturday12.Location = new System.Drawing.Point(259, 55);
            this.saturday12.Name = "saturday12";
            this.saturday12.Size = new System.Drawing.Size(121, 28);
            this.saturday12.TabIndex = 23;
            this.saturday12.SelectedIndexChanged += new System.EventHandler(this.saturday12_SelectedIndexChanged);
            // 
            // saturday11
            // 
            this.saturday11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saturday11.FormattingEnabled = true;
            this.saturday11.Location = new System.Drawing.Point(131, 55);
            this.saturday11.Name = "saturday11";
            this.saturday11.Size = new System.Drawing.Size(121, 28);
            this.saturday11.TabIndex = 22;
            this.saturday11.SelectedIndexChanged += new System.EventHandler(this.saturday11_SelectedIndexChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label36.Location = new System.Drawing.Point(28, 58);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(97, 20);
            this.label36.TabIndex = 21;
            this.label36.Text = "LECTURE 1";
            // 
            // AddTT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1127, 536);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1143, 575);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1143, 575);
            this.Name = "AddTT";
            this.Text = "AddTT";
            this.Load += new System.EventHandler(this.AddTT_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.Monday.ResumeLayout(false);
            this.Monday.PerformLayout();
            this.Tuesday.ResumeLayout(false);
            this.Tuesday.PerformLayout();
            this.Wednesday.ResumeLayout(false);
            this.Wednesday.PerformLayout();
            this.Thursday.ResumeLayout(false);
            this.Thursday.PerformLayout();
            this.Friday.ResumeLayout(false);
            this.Friday.PerformLayout();
            this.Saturday.ResumeLayout(false);
            this.Saturday.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Monday;
        private System.Windows.Forms.ComboBox monday62;
        private System.Windows.Forms.ComboBox monday61;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox monday52;
        private System.Windows.Forms.ComboBox monday51;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox monday42;
        private System.Windows.Forms.ComboBox monday41;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox monday32;
        private System.Windows.Forms.ComboBox monday31;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox monday22;
        private System.Windows.Forms.ComboBox monday21;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox monday12;
        private System.Windows.Forms.ComboBox monday11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage Tuesday;
        private System.Windows.Forms.ComboBox tuesday62;
        private System.Windows.Forms.ComboBox tuesday61;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox tuesday52;
        private System.Windows.Forms.ComboBox tuesday51;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox tuesday42;
        private System.Windows.Forms.ComboBox tuesday41;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox tuesday32;
        private System.Windows.Forms.ComboBox tuesday31;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox tuesday22;
        private System.Windows.Forms.ComboBox tuesday21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox tuesday12;
        private System.Windows.Forms.ComboBox tuesday11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage Wednesday;
        private System.Windows.Forms.ComboBox wednesday62;
        private System.Windows.Forms.ComboBox wednesday61;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox wednesday52;
        private System.Windows.Forms.ComboBox wednesday51;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox wednesday42;
        private System.Windows.Forms.ComboBox wednesday41;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox wednesday32;
        private System.Windows.Forms.ComboBox wednesday31;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox wednesday22;
        private System.Windows.Forms.ComboBox wednesday21;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox wednesday12;
        private System.Windows.Forms.ComboBox wednesday11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage Thursday;
        private System.Windows.Forms.ComboBox thursday62;
        private System.Windows.Forms.ComboBox thursday61;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox thursday52;
        private System.Windows.Forms.ComboBox thursday51;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox thursday42;
        private System.Windows.Forms.ComboBox thursday41;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox thursday32;
        private System.Windows.Forms.ComboBox thursday31;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox thursday22;
        private System.Windows.Forms.ComboBox thursday21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox thursday12;
        private System.Windows.Forms.ComboBox thursday11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TabPage Friday;
        private System.Windows.Forms.ComboBox friday62;
        private System.Windows.Forms.ComboBox friday61;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox friday52;
        private System.Windows.Forms.ComboBox friday51;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox friday42;
        private System.Windows.Forms.ComboBox friday41;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox friday32;
        private System.Windows.Forms.ComboBox friday31;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox friday22;
        private System.Windows.Forms.ComboBox friday21;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox friday12;
        private System.Windows.Forms.ComboBox friday11;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage Saturday;
        private System.Windows.Forms.ComboBox saturday62;
        private System.Windows.Forms.ComboBox saturday61;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox saturday52;
        private System.Windows.Forms.ComboBox saturday51;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox saturday42;
        private System.Windows.Forms.ComboBox saturday41;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox saturday32;
        private System.Windows.Forms.ComboBox saturday31;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox saturday22;
        private System.Windows.Forms.ComboBox saturday21;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox saturday12;
        private System.Windows.Forms.ComboBox saturday11;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader SCODE;
        private System.Windows.Forms.ColumnHeader SNAME;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader TID;
        private System.Windows.Forms.ColumnHeader TeacherName;
        private System.Windows.Forms.ColumnHeader SHORT;

    }
}