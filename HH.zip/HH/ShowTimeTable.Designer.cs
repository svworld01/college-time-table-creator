﻿namespace HH
{
    partial class ShowTimeTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.L11 = new System.Windows.Forms.Label();
            this.T11 = new System.Windows.Forms.Label();
            this.T12 = new System.Windows.Forms.Label();
            this.L12 = new System.Windows.Forms.Label();
            this.T13 = new System.Windows.Forms.Label();
            this.L13 = new System.Windows.Forms.Label();
            this.T14 = new System.Windows.Forms.Label();
            this.L14 = new System.Windows.Forms.Label();
            this.T15 = new System.Windows.Forms.Label();
            this.L15 = new System.Windows.Forms.Label();
            this.T16 = new System.Windows.Forms.Label();
            this.L16 = new System.Windows.Forms.Label();
            this.T26 = new System.Windows.Forms.Label();
            this.L26 = new System.Windows.Forms.Label();
            this.T25 = new System.Windows.Forms.Label();
            this.L25 = new System.Windows.Forms.Label();
            this.T24 = new System.Windows.Forms.Label();
            this.L24 = new System.Windows.Forms.Label();
            this.T23 = new System.Windows.Forms.Label();
            this.L23 = new System.Windows.Forms.Label();
            this.T22 = new System.Windows.Forms.Label();
            this.L22 = new System.Windows.Forms.Label();
            this.T21 = new System.Windows.Forms.Label();
            this.L21 = new System.Windows.Forms.Label();
            this.T36 = new System.Windows.Forms.Label();
            this.L36 = new System.Windows.Forms.Label();
            this.T35 = new System.Windows.Forms.Label();
            this.L35 = new System.Windows.Forms.Label();
            this.T34 = new System.Windows.Forms.Label();
            this.L34 = new System.Windows.Forms.Label();
            this.T33 = new System.Windows.Forms.Label();
            this.L33 = new System.Windows.Forms.Label();
            this.T32 = new System.Windows.Forms.Label();
            this.L32 = new System.Windows.Forms.Label();
            this.T31 = new System.Windows.Forms.Label();
            this.L31 = new System.Windows.Forms.Label();
            this.T46 = new System.Windows.Forms.Label();
            this.L46 = new System.Windows.Forms.Label();
            this.T45 = new System.Windows.Forms.Label();
            this.L45 = new System.Windows.Forms.Label();
            this.T44 = new System.Windows.Forms.Label();
            this.L44 = new System.Windows.Forms.Label();
            this.T43 = new System.Windows.Forms.Label();
            this.L43 = new System.Windows.Forms.Label();
            this.T42 = new System.Windows.Forms.Label();
            this.L42 = new System.Windows.Forms.Label();
            this.T41 = new System.Windows.Forms.Label();
            this.L41 = new System.Windows.Forms.Label();
            this.T56 = new System.Windows.Forms.Label();
            this.L56 = new System.Windows.Forms.Label();
            this.T55 = new System.Windows.Forms.Label();
            this.L55 = new System.Windows.Forms.Label();
            this.T54 = new System.Windows.Forms.Label();
            this.L54 = new System.Windows.Forms.Label();
            this.T53 = new System.Windows.Forms.Label();
            this.L53 = new System.Windows.Forms.Label();
            this.T52 = new System.Windows.Forms.Label();
            this.L52 = new System.Windows.Forms.Label();
            this.T51 = new System.Windows.Forms.Label();
            this.L51 = new System.Windows.Forms.Label();
            this.T66 = new System.Windows.Forms.Label();
            this.L66 = new System.Windows.Forms.Label();
            this.T65 = new System.Windows.Forms.Label();
            this.L65 = new System.Windows.Forms.Label();
            this.T64 = new System.Windows.Forms.Label();
            this.L64 = new System.Windows.Forms.Label();
            this.T63 = new System.Windows.Forms.Label();
            this.L63 = new System.Windows.Forms.Label();
            this.T62 = new System.Windows.Forms.Label();
            this.L62 = new System.Windows.Forms.Label();
            this.T61 = new System.Windows.Forms.Label();
            this.L61 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(19, 85);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(970, 520);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(960, 68);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.T16);
            this.panel3.Controls.Add(this.L16);
            this.panel3.Controls.Add(this.T15);
            this.panel3.Controls.Add(this.L15);
            this.panel3.Controls.Add(this.T14);
            this.panel3.Controls.Add(this.L14);
            this.panel3.Controls.Add(this.T13);
            this.panel3.Controls.Add(this.L13);
            this.panel3.Controls.Add(this.T12);
            this.panel3.Controls.Add(this.L12);
            this.panel3.Controls.Add(this.T11);
            this.panel3.Controls.Add(this.L11);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(4, 78);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(960, 68);
            this.panel3.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.T26);
            this.panel4.Controls.Add(this.L26);
            this.panel4.Controls.Add(this.T25);
            this.panel4.Controls.Add(this.L25);
            this.panel4.Controls.Add(this.T24);
            this.panel4.Controls.Add(this.L24);
            this.panel4.Controls.Add(this.T23);
            this.panel4.Controls.Add(this.L23);
            this.panel4.Controls.Add(this.T22);
            this.panel4.Controls.Add(this.L22);
            this.panel4.Controls.Add(this.T21);
            this.panel4.Controls.Add(this.L21);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(4, 152);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(960, 68);
            this.panel4.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.T36);
            this.panel5.Controls.Add(this.L36);
            this.panel5.Controls.Add(this.T35);
            this.panel5.Controls.Add(this.L35);
            this.panel5.Controls.Add(this.T34);
            this.panel5.Controls.Add(this.L34);
            this.panel5.Controls.Add(this.T33);
            this.panel5.Controls.Add(this.L33);
            this.panel5.Controls.Add(this.T32);
            this.panel5.Controls.Add(this.L32);
            this.panel5.Controls.Add(this.T31);
            this.panel5.Controls.Add(this.L31);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Location = new System.Drawing.Point(4, 226);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(960, 68);
            this.panel5.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.T46);
            this.panel6.Controls.Add(this.L46);
            this.panel6.Controls.Add(this.T45);
            this.panel6.Controls.Add(this.L45);
            this.panel6.Controls.Add(this.T44);
            this.panel6.Controls.Add(this.L44);
            this.panel6.Controls.Add(this.T43);
            this.panel6.Controls.Add(this.L43);
            this.panel6.Controls.Add(this.T42);
            this.panel6.Controls.Add(this.L42);
            this.panel6.Controls.Add(this.T41);
            this.panel6.Controls.Add(this.L41);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Location = new System.Drawing.Point(4, 300);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(960, 68);
            this.panel6.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.T56);
            this.panel7.Controls.Add(this.L56);
            this.panel7.Controls.Add(this.T55);
            this.panel7.Controls.Add(this.L55);
            this.panel7.Controls.Add(this.T54);
            this.panel7.Controls.Add(this.L54);
            this.panel7.Controls.Add(this.T53);
            this.panel7.Controls.Add(this.L53);
            this.panel7.Controls.Add(this.T52);
            this.panel7.Controls.Add(this.L52);
            this.panel7.Controls.Add(this.T51);
            this.panel7.Controls.Add(this.L51);
            this.panel7.Controls.Add(this.label11);
            this.panel7.Location = new System.Drawing.Point(4, 374);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(960, 68);
            this.panel7.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Control;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.T66);
            this.panel8.Controls.Add(this.L66);
            this.panel8.Controls.Add(this.T65);
            this.panel8.Controls.Add(this.L65);
            this.panel8.Controls.Add(this.T64);
            this.panel8.Controls.Add(this.L64);
            this.panel8.Controls.Add(this.T63);
            this.panel8.Controls.Add(this.L63);
            this.panel8.Controls.Add(this.T62);
            this.panel8.Controls.Add(this.L62);
            this.panel8.Controls.Add(this.T61);
            this.panel8.Controls.Add(this.L61);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Location = new System.Drawing.Point(4, 448);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(960, 68);
            this.panel8.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(175, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "LECTURE 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(311, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "LECTURE 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(435, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "LECTURE 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(571, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "LECTURE 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(693, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "LECTURE 5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(819, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "LECTURE 6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "MONDAY";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "TUESDAY";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "WEDNESDAY";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "THURSDAY";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(36, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "FRIDAY";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "SATURDAY";
            // 
            // L11
            // 
            this.L11.AutoSize = true;
            this.L11.Location = new System.Drawing.Point(188, 12);
            this.L11.Name = "L11";
            this.L11.Size = new System.Drawing.Size(25, 13);
            this.L11.TabIndex = 1;
            this.L11.Text = "------";
            // 
            // T11
            // 
            this.T11.AutoSize = true;
            this.T11.Location = new System.Drawing.Point(188, 36);
            this.T11.Name = "T11";
            this.T11.Size = new System.Drawing.Size(25, 13);
            this.T11.TabIndex = 2;
            this.T11.Text = "------";
            // 
            // T12
            // 
            this.T12.AutoSize = true;
            this.T12.Location = new System.Drawing.Point(325, 36);
            this.T12.Name = "T12";
            this.T12.Size = new System.Drawing.Size(25, 13);
            this.T12.TabIndex = 4;
            this.T12.Text = "------";
            // 
            // L12
            // 
            this.L12.AutoSize = true;
            this.L12.Location = new System.Drawing.Point(325, 12);
            this.L12.Name = "L12";
            this.L12.Size = new System.Drawing.Size(25, 13);
            this.L12.TabIndex = 3;
            this.L12.Text = "------";
            // 
            // T13
            // 
            this.T13.AutoSize = true;
            this.T13.Location = new System.Drawing.Point(445, 36);
            this.T13.Name = "T13";
            this.T13.Size = new System.Drawing.Size(25, 13);
            this.T13.TabIndex = 6;
            this.T13.Text = "------";
            // 
            // L13
            // 
            this.L13.AutoSize = true;
            this.L13.Location = new System.Drawing.Point(445, 12);
            this.L13.Name = "L13";
            this.L13.Size = new System.Drawing.Size(25, 13);
            this.L13.TabIndex = 5;
            this.L13.Text = "------";
            // 
            // T14
            // 
            this.T14.AutoSize = true;
            this.T14.Location = new System.Drawing.Point(580, 36);
            this.T14.Name = "T14";
            this.T14.Size = new System.Drawing.Size(25, 13);
            this.T14.TabIndex = 8;
            this.T14.Text = "------";
            // 
            // L14
            // 
            this.L14.AutoSize = true;
            this.L14.Location = new System.Drawing.Point(580, 12);
            this.L14.Name = "L14";
            this.L14.Size = new System.Drawing.Size(25, 13);
            this.L14.TabIndex = 7;
            this.L14.Text = "------";
            // 
            // T15
            // 
            this.T15.AutoSize = true;
            this.T15.Location = new System.Drawing.Point(713, 36);
            this.T15.Name = "T15";
            this.T15.Size = new System.Drawing.Size(25, 13);
            this.T15.TabIndex = 10;
            this.T15.Text = "------";
            // 
            // L15
            // 
            this.L15.AutoSize = true;
            this.L15.Location = new System.Drawing.Point(713, 12);
            this.L15.Name = "L15";
            this.L15.Size = new System.Drawing.Size(25, 13);
            this.L15.TabIndex = 9;
            this.L15.Text = "------";
            // 
            // T16
            // 
            this.T16.AutoSize = true;
            this.T16.Location = new System.Drawing.Point(839, 36);
            this.T16.Name = "T16";
            this.T16.Size = new System.Drawing.Size(25, 13);
            this.T16.TabIndex = 12;
            this.T16.Text = "------";
            // 
            // L16
            // 
            this.L16.AutoSize = true;
            this.L16.Location = new System.Drawing.Point(839, 12);
            this.L16.Name = "L16";
            this.L16.Size = new System.Drawing.Size(25, 13);
            this.L16.TabIndex = 11;
            this.L16.Text = "------";
            // 
            // T26
            // 
            this.T26.AutoSize = true;
            this.T26.Location = new System.Drawing.Point(839, 39);
            this.T26.Name = "T26";
            this.T26.Size = new System.Drawing.Size(25, 13);
            this.T26.TabIndex = 24;
            this.T26.Text = "------";
            // 
            // L26
            // 
            this.L26.AutoSize = true;
            this.L26.Location = new System.Drawing.Point(839, 15);
            this.L26.Name = "L26";
            this.L26.Size = new System.Drawing.Size(25, 13);
            this.L26.TabIndex = 23;
            this.L26.Text = "------";
            // 
            // T25
            // 
            this.T25.AutoSize = true;
            this.T25.Location = new System.Drawing.Point(713, 39);
            this.T25.Name = "T25";
            this.T25.Size = new System.Drawing.Size(25, 13);
            this.T25.TabIndex = 22;
            this.T25.Text = "------";
            // 
            // L25
            // 
            this.L25.AutoSize = true;
            this.L25.Location = new System.Drawing.Point(713, 15);
            this.L25.Name = "L25";
            this.L25.Size = new System.Drawing.Size(25, 13);
            this.L25.TabIndex = 21;
            this.L25.Text = "------";
            // 
            // T24
            // 
            this.T24.AutoSize = true;
            this.T24.Location = new System.Drawing.Point(580, 39);
            this.T24.Name = "T24";
            this.T24.Size = new System.Drawing.Size(25, 13);
            this.T24.TabIndex = 20;
            this.T24.Text = "------";
            // 
            // L24
            // 
            this.L24.AutoSize = true;
            this.L24.Location = new System.Drawing.Point(580, 15);
            this.L24.Name = "L24";
            this.L24.Size = new System.Drawing.Size(25, 13);
            this.L24.TabIndex = 19;
            this.L24.Text = "------";
            // 
            // T23
            // 
            this.T23.AutoSize = true;
            this.T23.Location = new System.Drawing.Point(445, 39);
            this.T23.Name = "T23";
            this.T23.Size = new System.Drawing.Size(25, 13);
            this.T23.TabIndex = 18;
            this.T23.Text = "------";
            // 
            // L23
            // 
            this.L23.AutoSize = true;
            this.L23.Location = new System.Drawing.Point(445, 15);
            this.L23.Name = "L23";
            this.L23.Size = new System.Drawing.Size(25, 13);
            this.L23.TabIndex = 17;
            this.L23.Text = "------";
            // 
            // T22
            // 
            this.T22.AutoSize = true;
            this.T22.Location = new System.Drawing.Point(325, 39);
            this.T22.Name = "T22";
            this.T22.Size = new System.Drawing.Size(25, 13);
            this.T22.TabIndex = 16;
            this.T22.Text = "------";
            // 
            // L22
            // 
            this.L22.AutoSize = true;
            this.L22.Location = new System.Drawing.Point(325, 15);
            this.L22.Name = "L22";
            this.L22.Size = new System.Drawing.Size(25, 13);
            this.L22.TabIndex = 15;
            this.L22.Text = "------";
            // 
            // T21
            // 
            this.T21.AutoSize = true;
            this.T21.Location = new System.Drawing.Point(188, 39);
            this.T21.Name = "T21";
            this.T21.Size = new System.Drawing.Size(25, 13);
            this.T21.TabIndex = 14;
            this.T21.Text = "------";
            // 
            // L21
            // 
            this.L21.AutoSize = true;
            this.L21.Location = new System.Drawing.Point(188, 15);
            this.L21.Name = "L21";
            this.L21.Size = new System.Drawing.Size(25, 13);
            this.L21.TabIndex = 13;
            this.L21.Text = "------";
            // 
            // T36
            // 
            this.T36.AutoSize = true;
            this.T36.Location = new System.Drawing.Point(839, 40);
            this.T36.Name = "T36";
            this.T36.Size = new System.Drawing.Size(25, 13);
            this.T36.TabIndex = 24;
            this.T36.Text = "------";
            // 
            // L36
            // 
            this.L36.AutoSize = true;
            this.L36.Location = new System.Drawing.Point(839, 16);
            this.L36.Name = "L36";
            this.L36.Size = new System.Drawing.Size(25, 13);
            this.L36.TabIndex = 23;
            this.L36.Text = "------";
            // 
            // T35
            // 
            this.T35.AutoSize = true;
            this.T35.Location = new System.Drawing.Point(713, 40);
            this.T35.Name = "T35";
            this.T35.Size = new System.Drawing.Size(25, 13);
            this.T35.TabIndex = 22;
            this.T35.Text = "------";
            // 
            // L35
            // 
            this.L35.AutoSize = true;
            this.L35.Location = new System.Drawing.Point(713, 16);
            this.L35.Name = "L35";
            this.L35.Size = new System.Drawing.Size(25, 13);
            this.L35.TabIndex = 21;
            this.L35.Text = "------";
            // 
            // T34
            // 
            this.T34.AutoSize = true;
            this.T34.Location = new System.Drawing.Point(580, 40);
            this.T34.Name = "T34";
            this.T34.Size = new System.Drawing.Size(25, 13);
            this.T34.TabIndex = 20;
            this.T34.Text = "------";
            // 
            // L34
            // 
            this.L34.AutoSize = true;
            this.L34.Location = new System.Drawing.Point(580, 16);
            this.L34.Name = "L34";
            this.L34.Size = new System.Drawing.Size(25, 13);
            this.L34.TabIndex = 19;
            this.L34.Text = "------";
            // 
            // T33
            // 
            this.T33.AutoSize = true;
            this.T33.Location = new System.Drawing.Point(445, 40);
            this.T33.Name = "T33";
            this.T33.Size = new System.Drawing.Size(25, 13);
            this.T33.TabIndex = 18;
            this.T33.Text = "------";
            // 
            // L33
            // 
            this.L33.AutoSize = true;
            this.L33.Location = new System.Drawing.Point(445, 16);
            this.L33.Name = "L33";
            this.L33.Size = new System.Drawing.Size(25, 13);
            this.L33.TabIndex = 17;
            this.L33.Text = "------";
            // 
            // T32
            // 
            this.T32.AutoSize = true;
            this.T32.Location = new System.Drawing.Point(325, 40);
            this.T32.Name = "T32";
            this.T32.Size = new System.Drawing.Size(25, 13);
            this.T32.TabIndex = 16;
            this.T32.Text = "------";
            // 
            // L32
            // 
            this.L32.AutoSize = true;
            this.L32.Location = new System.Drawing.Point(325, 16);
            this.L32.Name = "L32";
            this.L32.Size = new System.Drawing.Size(25, 13);
            this.L32.TabIndex = 15;
            this.L32.Text = "------";
            // 
            // T31
            // 
            this.T31.AutoSize = true;
            this.T31.Location = new System.Drawing.Point(188, 40);
            this.T31.Name = "T31";
            this.T31.Size = new System.Drawing.Size(25, 13);
            this.T31.TabIndex = 14;
            this.T31.Text = "------";
            // 
            // L31
            // 
            this.L31.AutoSize = true;
            this.L31.Location = new System.Drawing.Point(188, 16);
            this.L31.Name = "L31";
            this.L31.Size = new System.Drawing.Size(25, 13);
            this.L31.TabIndex = 13;
            this.L31.Text = "------";
            // 
            // T46
            // 
            this.T46.AutoSize = true;
            this.T46.Location = new System.Drawing.Point(839, 38);
            this.T46.Name = "T46";
            this.T46.Size = new System.Drawing.Size(25, 13);
            this.T46.TabIndex = 24;
            this.T46.Text = "------";
            // 
            // L46
            // 
            this.L46.AutoSize = true;
            this.L46.Location = new System.Drawing.Point(839, 14);
            this.L46.Name = "L46";
            this.L46.Size = new System.Drawing.Size(25, 13);
            this.L46.TabIndex = 23;
            this.L46.Text = "------";
            // 
            // T45
            // 
            this.T45.AutoSize = true;
            this.T45.Location = new System.Drawing.Point(713, 38);
            this.T45.Name = "T45";
            this.T45.Size = new System.Drawing.Size(25, 13);
            this.T45.TabIndex = 22;
            this.T45.Text = "------";
            // 
            // L45
            // 
            this.L45.AutoSize = true;
            this.L45.Location = new System.Drawing.Point(713, 14);
            this.L45.Name = "L45";
            this.L45.Size = new System.Drawing.Size(25, 13);
            this.L45.TabIndex = 21;
            this.L45.Text = "------";
            // 
            // T44
            // 
            this.T44.AutoSize = true;
            this.T44.Location = new System.Drawing.Point(580, 38);
            this.T44.Name = "T44";
            this.T44.Size = new System.Drawing.Size(25, 13);
            this.T44.TabIndex = 20;
            this.T44.Text = "------";
            // 
            // L44
            // 
            this.L44.AutoSize = true;
            this.L44.Location = new System.Drawing.Point(580, 14);
            this.L44.Name = "L44";
            this.L44.Size = new System.Drawing.Size(25, 13);
            this.L44.TabIndex = 19;
            this.L44.Text = "------";
            // 
            // T43
            // 
            this.T43.AutoSize = true;
            this.T43.Location = new System.Drawing.Point(445, 38);
            this.T43.Name = "T43";
            this.T43.Size = new System.Drawing.Size(25, 13);
            this.T43.TabIndex = 18;
            this.T43.Text = "------";
            // 
            // L43
            // 
            this.L43.AutoSize = true;
            this.L43.Location = new System.Drawing.Point(445, 14);
            this.L43.Name = "L43";
            this.L43.Size = new System.Drawing.Size(25, 13);
            this.L43.TabIndex = 17;
            this.L43.Text = "------";
            // 
            // T42
            // 
            this.T42.AutoSize = true;
            this.T42.Location = new System.Drawing.Point(325, 38);
            this.T42.Name = "T42";
            this.T42.Size = new System.Drawing.Size(25, 13);
            this.T42.TabIndex = 16;
            this.T42.Text = "------";
            // 
            // L42
            // 
            this.L42.AutoSize = true;
            this.L42.Location = new System.Drawing.Point(325, 14);
            this.L42.Name = "L42";
            this.L42.Size = new System.Drawing.Size(25, 13);
            this.L42.TabIndex = 15;
            this.L42.Text = "------";
            // 
            // T41
            // 
            this.T41.AutoSize = true;
            this.T41.Location = new System.Drawing.Point(188, 38);
            this.T41.Name = "T41";
            this.T41.Size = new System.Drawing.Size(25, 13);
            this.T41.TabIndex = 14;
            this.T41.Text = "------";
            // 
            // L41
            // 
            this.L41.AutoSize = true;
            this.L41.Location = new System.Drawing.Point(188, 14);
            this.L41.Name = "L41";
            this.L41.Size = new System.Drawing.Size(25, 13);
            this.L41.TabIndex = 13;
            this.L41.Text = "------";
            // 
            // T56
            // 
            this.T56.AutoSize = true;
            this.T56.Location = new System.Drawing.Point(839, 39);
            this.T56.Name = "T56";
            this.T56.Size = new System.Drawing.Size(25, 13);
            this.T56.TabIndex = 24;
            this.T56.Text = "------";
            // 
            // L56
            // 
            this.L56.AutoSize = true;
            this.L56.Location = new System.Drawing.Point(839, 15);
            this.L56.Name = "L56";
            this.L56.Size = new System.Drawing.Size(25, 13);
            this.L56.TabIndex = 23;
            this.L56.Text = "------";
            // 
            // T55
            // 
            this.T55.AutoSize = true;
            this.T55.Location = new System.Drawing.Point(713, 39);
            this.T55.Name = "T55";
            this.T55.Size = new System.Drawing.Size(25, 13);
            this.T55.TabIndex = 22;
            this.T55.Text = "------";
            // 
            // L55
            // 
            this.L55.AutoSize = true;
            this.L55.Location = new System.Drawing.Point(713, 15);
            this.L55.Name = "L55";
            this.L55.Size = new System.Drawing.Size(25, 13);
            this.L55.TabIndex = 21;
            this.L55.Text = "------";
            // 
            // T54
            // 
            this.T54.AutoSize = true;
            this.T54.Location = new System.Drawing.Point(580, 39);
            this.T54.Name = "T54";
            this.T54.Size = new System.Drawing.Size(25, 13);
            this.T54.TabIndex = 20;
            this.T54.Text = "------";
            // 
            // L54
            // 
            this.L54.AutoSize = true;
            this.L54.Location = new System.Drawing.Point(580, 15);
            this.L54.Name = "L54";
            this.L54.Size = new System.Drawing.Size(25, 13);
            this.L54.TabIndex = 19;
            this.L54.Text = "------";
            // 
            // T53
            // 
            this.T53.AutoSize = true;
            this.T53.Location = new System.Drawing.Point(445, 39);
            this.T53.Name = "T53";
            this.T53.Size = new System.Drawing.Size(25, 13);
            this.T53.TabIndex = 18;
            this.T53.Text = "------";
            // 
            // L53
            // 
            this.L53.AutoSize = true;
            this.L53.Location = new System.Drawing.Point(445, 15);
            this.L53.Name = "L53";
            this.L53.Size = new System.Drawing.Size(25, 13);
            this.L53.TabIndex = 17;
            this.L53.Text = "------";
            // 
            // T52
            // 
            this.T52.AutoSize = true;
            this.T52.Location = new System.Drawing.Point(325, 39);
            this.T52.Name = "T52";
            this.T52.Size = new System.Drawing.Size(25, 13);
            this.T52.TabIndex = 16;
            this.T52.Text = "------";
            // 
            // L52
            // 
            this.L52.AutoSize = true;
            this.L52.Location = new System.Drawing.Point(325, 15);
            this.L52.Name = "L52";
            this.L52.Size = new System.Drawing.Size(25, 13);
            this.L52.TabIndex = 15;
            this.L52.Text = "------";
            // 
            // T51
            // 
            this.T51.AutoSize = true;
            this.T51.Location = new System.Drawing.Point(188, 39);
            this.T51.Name = "T51";
            this.T51.Size = new System.Drawing.Size(25, 13);
            this.T51.TabIndex = 14;
            this.T51.Text = "------";
            // 
            // L51
            // 
            this.L51.AutoSize = true;
            this.L51.Location = new System.Drawing.Point(188, 15);
            this.L51.Name = "L51";
            this.L51.Size = new System.Drawing.Size(25, 13);
            this.L51.TabIndex = 13;
            this.L51.Text = "------";
            // 
            // T66
            // 
            this.T66.AutoSize = true;
            this.T66.Location = new System.Drawing.Point(839, 37);
            this.T66.Name = "T66";
            this.T66.Size = new System.Drawing.Size(25, 13);
            this.T66.TabIndex = 24;
            this.T66.Text = "------";
            // 
            // L66
            // 
            this.L66.AutoSize = true;
            this.L66.Location = new System.Drawing.Point(839, 13);
            this.L66.Name = "L66";
            this.L66.Size = new System.Drawing.Size(25, 13);
            this.L66.TabIndex = 23;
            this.L66.Text = "------";
            // 
            // T65
            // 
            this.T65.AutoSize = true;
            this.T65.Location = new System.Drawing.Point(713, 37);
            this.T65.Name = "T65";
            this.T65.Size = new System.Drawing.Size(25, 13);
            this.T65.TabIndex = 22;
            this.T65.Text = "------";
            // 
            // L65
            // 
            this.L65.AutoSize = true;
            this.L65.Location = new System.Drawing.Point(713, 13);
            this.L65.Name = "L65";
            this.L65.Size = new System.Drawing.Size(25, 13);
            this.L65.TabIndex = 21;
            this.L65.Text = "------";
            // 
            // T64
            // 
            this.T64.AutoSize = true;
            this.T64.Location = new System.Drawing.Point(580, 37);
            this.T64.Name = "T64";
            this.T64.Size = new System.Drawing.Size(25, 13);
            this.T64.TabIndex = 20;
            this.T64.Text = "------";
            // 
            // L64
            // 
            this.L64.AutoSize = true;
            this.L64.Location = new System.Drawing.Point(580, 13);
            this.L64.Name = "L64";
            this.L64.Size = new System.Drawing.Size(25, 13);
            this.L64.TabIndex = 19;
            this.L64.Text = "------";
            // 
            // T63
            // 
            this.T63.AutoSize = true;
            this.T63.Location = new System.Drawing.Point(445, 37);
            this.T63.Name = "T63";
            this.T63.Size = new System.Drawing.Size(25, 13);
            this.T63.TabIndex = 18;
            this.T63.Text = "------";
            // 
            // L63
            // 
            this.L63.AutoSize = true;
            this.L63.Location = new System.Drawing.Point(445, 13);
            this.L63.Name = "L63";
            this.L63.Size = new System.Drawing.Size(25, 13);
            this.L63.TabIndex = 17;
            this.L63.Text = "------";
            // 
            // T62
            // 
            this.T62.AutoSize = true;
            this.T62.Location = new System.Drawing.Point(325, 37);
            this.T62.Name = "T62";
            this.T62.Size = new System.Drawing.Size(25, 13);
            this.T62.TabIndex = 16;
            this.T62.Text = "------";
            // 
            // L62
            // 
            this.L62.AutoSize = true;
            this.L62.Location = new System.Drawing.Point(325, 13);
            this.L62.Name = "L62";
            this.L62.Size = new System.Drawing.Size(25, 13);
            this.L62.TabIndex = 15;
            this.L62.Text = "------";
            // 
            // T61
            // 
            this.T61.AutoSize = true;
            this.T61.Location = new System.Drawing.Point(188, 37);
            this.T61.Name = "T61";
            this.T61.Size = new System.Drawing.Size(25, 13);
            this.T61.TabIndex = 14;
            this.T61.Text = "------";
            // 
            // L61
            // 
            this.L61.AutoSize = true;
            this.L61.Location = new System.Drawing.Point(188, 13);
            this.L61.Name = "L61";
            this.L61.Size = new System.Drawing.Size(25, 13);
            this.L61.TabIndex = 13;
            this.L61.Text = "------";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(315, 9);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(58, 13);
            this.label85.TabIndex = 1;
            this.label85.Text = "BRANCH -";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(315, 33);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(48, 13);
            this.label86.TabIndex = 2;
            this.label86.Text = "YEAR  - ";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(315, 56);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(44, 13);
            this.label87.TabIndex = 3;
            this.label87.Text = "SHIFT -";
            // 
            // ShowTimeTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 617);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.panel1);
            this.Name = "ShowTimeTable";
            this.Text = "ShowTimeTable";
            this.Load += new System.EventHandler(this.ShowTimeTable_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label T66;
        private System.Windows.Forms.Label L66;
        private System.Windows.Forms.Label T65;
        private System.Windows.Forms.Label L65;
        private System.Windows.Forms.Label T64;
        private System.Windows.Forms.Label L64;
        private System.Windows.Forms.Label T63;
        private System.Windows.Forms.Label L63;
        private System.Windows.Forms.Label T62;
        private System.Windows.Forms.Label L62;
        private System.Windows.Forms.Label T61;
        private System.Windows.Forms.Label L61;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label T56;
        private System.Windows.Forms.Label L56;
        private System.Windows.Forms.Label T55;
        private System.Windows.Forms.Label L55;
        private System.Windows.Forms.Label T54;
        private System.Windows.Forms.Label L54;
        private System.Windows.Forms.Label T53;
        private System.Windows.Forms.Label L53;
        private System.Windows.Forms.Label T52;
        private System.Windows.Forms.Label L52;
        private System.Windows.Forms.Label T51;
        private System.Windows.Forms.Label L51;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label T46;
        private System.Windows.Forms.Label L46;
        private System.Windows.Forms.Label T45;
        private System.Windows.Forms.Label L45;
        private System.Windows.Forms.Label T44;
        private System.Windows.Forms.Label L44;
        private System.Windows.Forms.Label T43;
        private System.Windows.Forms.Label L43;
        private System.Windows.Forms.Label T42;
        private System.Windows.Forms.Label L42;
        private System.Windows.Forms.Label T41;
        private System.Windows.Forms.Label L41;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label T36;
        private System.Windows.Forms.Label L36;
        private System.Windows.Forms.Label T35;
        private System.Windows.Forms.Label L35;
        private System.Windows.Forms.Label T34;
        private System.Windows.Forms.Label L34;
        private System.Windows.Forms.Label T33;
        private System.Windows.Forms.Label L33;
        private System.Windows.Forms.Label T32;
        private System.Windows.Forms.Label L32;
        private System.Windows.Forms.Label T31;
        private System.Windows.Forms.Label L31;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label T26;
        private System.Windows.Forms.Label L26;
        private System.Windows.Forms.Label T25;
        private System.Windows.Forms.Label L25;
        private System.Windows.Forms.Label T24;
        private System.Windows.Forms.Label L24;
        private System.Windows.Forms.Label T23;
        private System.Windows.Forms.Label L23;
        private System.Windows.Forms.Label T22;
        private System.Windows.Forms.Label L22;
        private System.Windows.Forms.Label T21;
        private System.Windows.Forms.Label L21;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label T16;
        private System.Windows.Forms.Label L16;
        private System.Windows.Forms.Label T15;
        private System.Windows.Forms.Label L15;
        private System.Windows.Forms.Label T14;
        private System.Windows.Forms.Label L14;
        private System.Windows.Forms.Label T13;
        private System.Windows.Forms.Label L13;
        private System.Windows.Forms.Label T12;
        private System.Windows.Forms.Label L12;
        private System.Windows.Forms.Label T11;
        private System.Windows.Forms.Label L11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;


    }
}